/* global shadowRecon */

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const state = {
  traffic: [],
  maxTrafficRows: 250
};

function setActiveTab(tabId) {
  $$('.tab').forEach((t) => t.classList.remove('active'));
  $$('.tabBtn').forEach((b) => b.classList.remove('active'));
  $(`#${tabId}`).classList.add('active');
  $(`.tabBtn[data-tab="${tabId}"]`).classList.add('active');
}

function normalizeUrl(input) {
  const v = String(input || '').trim();
  if (!v) return '';
  try {
    const u = new URL(v);
    return u.toString();
  } catch (_) {
    try {
      const u2 = new URL(`https://${v}`);
      return u2.toString();
    } catch (e) {
      return '';
    }
  }
}

function appendFeedItem(item) {
  const feed = $('#feed');
  if (!feed) return;

  const wrap = document.createElement('div');
  wrap.className = 'feedItem';

  const pill = document.createElement('div');
  pill.className = `pill ${item.level || 'info'}`;
  pill.textContent = String(item.level || 'info').toUpperCase();

  const body = document.createElement('div');
  body.style.flex = '1';

  const msg = document.createElement('div');
  msg.className = 'feedMsg';
  msg.textContent = item.message || '';

  const ts = document.createElement('div');
  ts.className = 'feedTs';
  ts.textContent = new Date(item.ts || Date.now()).toLocaleString();

  body.appendChild(msg);
  body.appendChild(ts);
  wrap.appendChild(pill);
  wrap.appendChild(body);

  feed.appendChild(wrap);
  feed.scrollTop = feed.scrollHeight;
}

function setProgress(current, total, label) {
  const bar = $('#progressBar');
  const text = $('#progressText');
  const pct = total ? Math.round((current / total) * 100) : 0;
  bar.style.width = `${Math.max(0, Math.min(100, pct))}%`;
  text.textContent = `${label} (${current}/${total})`;
}

function trafficRow(entry) {
  const tr = document.createElement('tr');
  const td = (v, cls) => {
    const x = document.createElement('td');
    if (cls) x.className = cls;
    x.textContent = v;
    return x;
  };

  const timeStr = new Date(entry.ts || Date.now()).toLocaleTimeString();
  tr.appendChild(td(timeStr, 'mono'));

  const statusStr = entry.status ? String(entry.status) : '';
  tr.appendChild(td(statusStr, 'mono'));

  tr.appendChild(td(entry.method || '', 'mono'));
  tr.appendChild(td(entry.resourceType || '', 'mono'));
  tr.appendChild(td(entry.url || '', 'mono'));
  return tr;
}

function addTraffic(entry) {
  state.traffic.push(entry);
  if (state.traffic.length > 3000) state.traffic.splice(0, state.traffic.length - 3000);

  const body = $('#trafficBody');
  if (!body) return;

  body.appendChild(trafficRow(entry));
  while (body.children.length > state.maxTrafficRows) body.removeChild(body.firstChild);
}

function clearTrafficTable() {
  state.traffic = [];
  const body = $('#trafficBody');
  if (body) body.innerHTML = '';
}

function updateReportsPreview(fusionData) {
  $('#fusionPreview').textContent = JSON.stringify(fusionData, null, 2);
}

async function refreshFusionPreview() {
  try {
    const data = await shadowRecon.getFusionData();
    updateReportsPreview(data);
  } catch (_) {}
}

// Cyber-dragon animation: canvas glow "dragon" that follows cursor smoothly.
function startDragon() {
  const canvas = $('#dragonCanvas');
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  let w = 0;
  let h = 0;

  const mouse = { x: window.innerWidth * 0.5, y: window.innerHeight * 0.2 };
  const dragon = { x: mouse.x, y: mouse.y, vx: 0, vy: 0, t: 0 };

  function resize() {
    w = window.innerWidth;
    h = window.innerHeight;
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  window.addEventListener('resize', resize);
  window.addEventListener('mousemove', (e) => {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
  });

  resize();

  function drawDragonGlow(x, y, angle, phase) {
    const len = 110;
    const segments = 18;
    const dx = Math.cos(angle);
    const dy = Math.sin(angle);

    // Head glow
    const gHead = ctx.createRadialGradient(x, y, 2, x, y, 28);
    gHead.addColorStop(0, 'rgba(64,230,255,0.85)');
    gHead.addColorStop(0.55, 'rgba(255,59,212,0.35)');
    gHead.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = gHead;
    ctx.beginPath();
    ctx.arc(x, y, 28, 0, Math.PI * 2);
    ctx.fill();

    // Body trail
    for (let i = 0; i < segments; i++) {
      const p = i / segments;
      const wobble = Math.sin(phase + p * 9) * (10 + 14 * (1 - p));
      const bx = x - dx * (p * len) + (-dy) * wobble;
      const by = y - dy * (p * len) + (dx) * wobble;
      const r = 16 * (1 - p) + 3;

      const g = ctx.createRadialGradient(bx, by, 1, bx, by, r);
      g.addColorStop(0, `rgba(32,255,179,${0.35 * (1 - p)})`);
      g.addColorStop(0.35, `rgba(64,230,255,${0.28 * (1 - p)})`);
      g.addColorStop(0.7, `rgba(255,59,212,${0.22 * (1 - p)})`);
      g.addColorStop(1, 'rgba(0,0,0,0)');

      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(bx, by, r, 0, Math.PI * 2);
      ctx.fill();
    }

    // Wings flicker
    const wingSpan = 42 + 8 * Math.sin(phase * 1.2);
    ctx.strokeStyle = 'rgba(255,59,212,0.18)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x - dy * 6, y + dx * 6);
    ctx.quadraticCurveTo(x - dy * wingSpan, y + dx * wingSpan, x - dy * (wingSpan * 1.2), y + dx * (wingSpan * 0.2));
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x + dy * 6, y - dx * 6);
    ctx.quadraticCurveTo(x + dy * wingSpan, y - dx * wingSpan, x + dy * (wingSpan * 1.2), y - dx * (wingSpan * 0.2));
    ctx.stroke();
  }

  function frame() {
    dragon.t += 0.016;
    // spring-follow motion
    const ax = (mouse.x - dragon.x) * 0.018;
    const ay = (mouse.y - dragon.y) * 0.018;
    dragon.vx = (dragon.vx + ax) * 0.86;
    dragon.vy = (dragon.vy + ay) * 0.86;
    dragon.x += dragon.vx;
    dragon.y += dragon.vy;

    const angle = Math.atan2(dragon.vy, dragon.vx);

    ctx.clearRect(0, 0, w, h);
    drawDragonGlow(dragon.x, dragon.y, angle, dragon.t);

    requestAnimationFrame(frame);
  }

  frame();
}

async function runDefensiveWorkflow() {
  const webview = $('#webview');
  const input = $('#targetInput');
  const urlFromInput = normalizeUrl(input.value);
  const current = webview.getURL ? webview.getURL() : '';
  const target = urlFromInput || normalizeUrl(current);

  if (!target) {
    appendFeedItem({ ts: new Date().toISOString(), level: 'warn', message: 'একটি বৈধ Target URL দিন (https://example.com)।' });
    return;
  }

  setActiveTab('tabChecks');
  setProgress(0, 12, 'Starting');
  appendFeedItem({ ts: new Date().toISOString(), level: 'info', message: `Defensive checks শুরু হচ্ছে: ${target}` });

  const res = await shadowRecon.runDefensiveChecks(target);
  if (!res.ok) {
    appendFeedItem({ ts: new Date().toISOString(), level: 'error', message: `Defensive checks ব্যর্থ: ${res.error || 'unknown'}` });
    return;
  }
  $('#lastRun').textContent = JSON.stringify(res.artifacts, null, 2);
  await refreshFusionPreview();
  setActiveTab('tabReports');
}

async function runCustomTools() {
  setActiveTab('tabChecks');
  appendFeedItem({ ts: new Date().toISOString(), level: 'info', message: 'Custom tools রান করার চেষ্টা করা হচ্ছে…' });
  const res = await shadowRecon.runCustomTools();
  if (!res.ok) {
    appendFeedItem({ ts: new Date().toISOString(), level: 'warn', message: res.message || 'Custom tools not implemented.' });
    return;
  }
  await refreshFusionPreview();
  setActiveTab('tabReports');
}

async function compressReports() {
  appendFeedItem({ ts: new Date().toISOString(), level: 'info', message: 'ZIP তৈরি হচ্ছে…' });
  const res = await shadowRecon.compressReports(false);
  if (!res.ok) {
    appendFeedItem({ ts: new Date().toISOString(), level: 'error', message: `ZIP export ব্যর্থ: ${res.error || 'unknown'}` });
    return;
  }
  appendFeedItem({ ts: new Date().toISOString(), level: 'success', message: 'ZIP export সম্পন্ন। Downloads ফোল্ডারে সেভ হয়েছে।' });
}

function wireUI() {
  $$('.tabBtn').forEach((btn) => {
    btn.addEventListener('click', () => setActiveTab(btn.dataset.tab));
  });

  const webview = $('#webview');
  const input = $('#targetInput');

  $('#goBtn').addEventListener('click', () => {
    const u = normalizeUrl(input.value);
    if (!u) {
      appendFeedItem({ ts: new Date().toISOString(), level: 'warn', message: 'বৈধ URL দিন।' });
      return;
    }
    webview.src = u;
    setActiveTab('tabBrowser');
  });

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') $('#goBtn').click();
  });

  $('#runDefensiveBtn').addEventListener('click', runDefensiveWorkflow);
  $('#runCustomBtn').addEventListener('click', runCustomTools);
  $('#compressBtn').addEventListener('click', compressReports);
  $('#clearTrafficBtn').addEventListener('click', clearTrafficTable);

  // Keep input synced with the currently browsed origin when possible
  webview.addEventListener('did-navigate', (e) => {
    if (e && e.url) input.value = e.url;
  });
  webview.addEventListener('did-navigate-in-page', (e) => {
    if (e && e.url) input.value = e.url;
  });
}

function wireIPC() {
  shadowRecon.onFeedItem((item) => appendFeedItem(item));
  shadowRecon.onTrafficEvent((entry) => addTraffic(entry));
  shadowRecon.onProgress((p) => setProgress(p.current, p.total, p.label));
  shadowRecon.onAnalysisDone(async () => {
    await refreshFusionPreview();
  });
}

async function init() {
  wireUI();
  wireIPC();
  startDragon();
  await refreshFusionPreview();
  appendFeedItem({ ts: new Date().toISOString(), level: 'info', message: 'Ready. WebView ব্রাউজ করুন অথবা Defensive checks চালান।' });
}

init();

