/**
 * toolRunner.js
 * -------------
 * এখানে আপনি ঠিক করবেন:
 * - customModules.js থেকে পাওয়া মডিউলগুলো কীভাবে কল করবেন
 * - আউটপুট কোথায়/কীভাবে `fusionData` (global.fusionData) এর ভেতরে জমা করবেন
 * - UI feed এ কীভাবে লগ দিবেন (emitFeed ব্যবহার করে)
 *
 * আপনার ইমপ্লিমেন্টেশনে এই সিগনেচার অনুসরণ করুন:
 *   async function runCustomTools({ modules, fusionData, emitFeed }) { ... }
 *
 * প্রত্যাশিত কনভেনশন:
 * - modules: { toolName: async function(...) {}, ... }
 * - fusionData.custom.results এ ফলাফল লিখুন
 * - কোন টুল ব্যর্থ হলে try/catch করে নরমালাইজড আউটপুট লিখুন
 */

async function runCustomTools({ modules, fusionData, emitFeed }) {
  // ইচ্ছাকৃতভাবে ইমপ্লিমেন্ট করা হয়নি।
  // আপনি এখানে modules এর টুলগুলো চালিয়ে fusionData আপডেট করবেন।
  // উদাহরণ কাঠামো (আপনি লিখবেন):
  //   for (const [name, fn] of Object.entries(modules)) {
  //     emitFeed('info', `Running ${name}…`);
  //     const out = await fn({ targetUrl: fusionData.target.url, fusionData, emitFeed });
  //     fusionData.custom.results[name] = out;
  //   }
  throw new Error('Not implemented');
}

module.exports = {
  runCustomTools
};

